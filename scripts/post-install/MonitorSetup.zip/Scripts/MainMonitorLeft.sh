#!/bin/bash
ddcutil -d 1 setvcp 60 0x0f
gnome-randr modify DP-1 --primary
