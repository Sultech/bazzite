#!/bin/bash
ddcutil -d 1 setvcp 60 0x12
gnome-randr modify DP-3 --primary
